import pandas

state = pandas.read_csv("50_states.csv")
states = state["state"].to_list()
x_cor = state["x"].to_list()
y_cor = state["y"].to_list()

location = []
for i in range(0, len(x_cor) - 1):
    coordinates = (x_cor[i], y_cor[i])
    location.append(coordinates)


