from turtle import Turtle, Screen

import pandas

from Data import states, location

screen = Screen()
screen.bgpic("blank_states_img.gif")
screen.setup(725,491)
screen.title("US-States Game")

writer = Turtle()
writer.hideturtle()
writer.penup()

game_is_on = True
guessed_states = []


while game_is_on:
    user_guess = screen.textinput(f"Guess States {len(guessed_states)}/{len(states)}","Enter the name of the state: ").title()
    for index, state in enumerate(states):
        if user_guess == state:
            guessed_states.append(state)
            writer.goto(location[index])
            writer.write(state, font= ("Arial", 8, "bold"))
        elif user_guess == "Exit":
            game_is_on = False
            break

missed_states = [state for state in states if state not in guessed_states]

pandas.DataFrame(missed_states).to_csv("states_to_learn.csv")


