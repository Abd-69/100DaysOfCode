from quiz_brain import questions

not_done = True
index = 0
score = 0

print("Welcome to the QUIZ GAME!!!")
print("Answer each question with either True or False")

while not_done and index < len(questions):
    print(questions[index].question)
    answer = input("True or False? ")
    if answer == questions[index].answer:
        print("Correct!")
        index += 1
        score += 1
    else:
        print("Wrong, GAME OVER!")
        not_done = False

