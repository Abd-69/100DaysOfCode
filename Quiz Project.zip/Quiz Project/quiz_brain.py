from data import question_data
from question_model import Question

questions = []

for i in range(0, len(question_data) - 1):
    question = Question(question_data[i]["text"], question_data[i]["answer"])
    questions.append(question)

