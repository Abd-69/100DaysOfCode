BACKGROUND_COLOR = "#B1DDC6"
from tkinter import *
import pandas
import random
import time

try:
    data = pandas.read_csv("data/Words_to_Learn.csv")
except pandas.errors.EmptyDataError:
    data = pandas.read_csv("data/french_words.csv")
except FileNotFoundError:
    data = pandas.read_csv("data/french_words.csv")

french_words = data["French"].to_list()
translation = data["English"].to_list()
words_learnt = []
random_index = None
flip_timer = None


#Word Generation:

def know():
    word_to_learn = french_words[random_index]
    its_translation = translation[random_index]
    words_learnt.append([word_to_learn, its_translation])

    french_words.pop(random_index)
    translation.pop(random_index)

    words_to_learn = [
        [french_words[i], translation[i]]
        for i in range(len(french_words))
    ]
    pandas.DataFrame(words_to_learn, columns=["French", "English"]).to_csv("data/Words_to_Learn.csv", index=False)

    generate_french_words()


def generate_french_words():
    global random_index
    if flip_timer:
        window.after_cancel(flip_timer)
    random_index = random.randint(0, len(french_words) - 1)
    canvas.itemconfig(word, text= french_words[random_index], fill= "black")
    canvas.itemconfig(language, text= "French", fill= "black")
    canvas.itemconfig(card_image, image= CARD_FRONT)
    card_flip()

def generate_translation():
    global random_index
    canvas.itemconfig(word, text= translation[random_index], fill= "white")
    canvas.itemconfig(language, text= "English", fill= "white")
    canvas.itemconfig(card_image, image=CARD_BACK)


#Card Flipping:

def card_flip():
    global flip_timer
    flip_timer = window.after(3000, func=generate_translation)



#UI Setup:

window = Tk()
window.title("Flash Card Game")
window.config(padx= 50, pady= 50, background= BACKGROUND_COLOR)

CARD_BACK = PhotoImage(file="images/card_back.png")
CARD_FRONT = PhotoImage(file= "images/card_front.png")

canvas = Canvas(width=800, height=526, background= BACKGROUND_COLOR, highlightthickness= 0)
card_image = canvas.create_image(400, 263, image= CARD_FRONT)
canvas.grid(column=0, row=0, columnspan=2)

language = canvas.create_text(400, 150, text= "", font= ("Ariel", 40, "italic"))
word = canvas.create_text(400, 263, text= "", font= ("Ariel", 60, "bold"))

w_img = PhotoImage(file= "images/wrong.png")
wrong = Button(image= w_img, highlightthickness= 0, width=100, height=99, command= generate_french_words)
wrong.grid(column= 0, row= 1)

r_img = PhotoImage(file= "images/right.png")
right = Button(image= r_img, highlightthickness= 0, width=100, height=100, command= know)
right.grid(column= 1, row= 1)


generate_french_words()
window.mainloop()

words_to_learn = [
    [french_words[i], translation[i]]
    for i in range(len(french_words))
    if [french_words[i], translation[i]] not in words_learnt
]

pandas.DataFrame(words_to_learn, columns=["French", "English"]).to_csv("data/Words_to_Learn.csv", index=False)

