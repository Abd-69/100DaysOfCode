from ctypes import windll
from tkinter import *
from quiz_brain import QuizBrain

THEME_COLOR = "#375362"

class QuizInterface:

    def __init__(self, quiz : QuizBrain):
        self.quiz = quiz
        self.is_right = True
        self.score_count = 0
        self.window = Tk()
        self.window.title("Quiz Application")
        self.window.config(padx= 20, pady= 20, background= THEME_COLOR)

        self.score = Label(text=f"Score: {self.score_count}", background=THEME_COLOR, fg= "white")
        self.score.grid(column=1, row=0)

        self.canvas = Canvas(width= 300, height= 250, background= "white")
        self.question_text = self.canvas.create_text(150, 125, text= "", font= ("Arial", 20, "italic"), fill= THEME_COLOR, width= 280)
        self.canvas.grid(column= 0, row= 1, columnspan= 2, pady= 50)

        self.t_image = PhotoImage(file= "images/true.png")
        self.f_image = PhotoImage(file="images/false.png")
        self.true = Button(image= self.t_image, background= THEME_COLOR, highlightthickness= 0, command= self.response_true)
        self.true.grid(column= 0, row= 2)
        self.false = Button(image= self.f_image, background= THEME_COLOR, highlightthickness= 0, command= self.response_false)
        self.false.grid(column=1, row=2)

        self.get_next_question()

        self.window.mainloop()

    def response_true(self):
        self.give_feedback(self.quiz.check_answer("True"))

    def response_false(self):
        self.is_right = self.quiz.check_answer("False")
        self.give_feedback(self.is_right)

    def get_next_question(self):
        if self.quiz.still_has_questions():
            self.canvas.config(bg="white")
            question = self.quiz.next_question()
            self.canvas.itemconfig(self.question_text, text=question)
            self.score.config(text=f"Score : {self.score_count}")
        else:
            self.canvas.config(bg="white")
            self.canvas.itemconfig(self.question_text, text= f"You've reached the end of the quiz!!! \nYour Score: {self.score_count}/10")

    def give_feedback(self, answer):
        if answer:
            self.score_count += 1
            self.canvas.config(background= "green")
        else:
            self.canvas.config(background= "red")
        self.window.after(1000, func= self.get_next_question)

