from turtle import Turtle

positions = [(0, 0), (-20, 0), (-40, 0)]
game_over = Turtle()
game_over.hideturtle()
game_over.color("white")


class Snake:

    def __init__(self):
        self.segments = []
        self.create_snake()

    def create_snake(self):
        for position in positions:
            snake_segment = Turtle("square")
            snake_segment.penup()
            snake_segment.color("white")
            snake_segment.goto(position)
            self.segments.append(snake_segment)

    def move(self):
        for seg_num in range(len(self.segments) - 1, 0, -1):
            new_x = self.segments[seg_num - 1].xcor()
            new_y = self.segments[seg_num - 1].ycor()
            self.segments[seg_num].goto(new_x, new_y)
        self.segments[0].forward(20)

    def up(self):
        if self.segments[0].heading() != 270:
            self.segments[0].setheading(90)

    def down(self):
        if self.segments[0].heading() != 90:
            self.segments[0].setheading(270)

    def right(self):
        if self.segments[0].heading() != 180:
            self.segments[0].setheading(0)

    def left(self):
        if self.segments[0].heading() != 0:
            self.segments[0].setheading(180)

    def extend(self):
        new_segment = Turtle("square")
        new_segment.penup()
        new_segment.color("white")
        last_pos = self.segments[-1].position()
        new_segment.goto(last_pos)
        self.segments.append(new_segment)

    def detect_collision(self):
        if self.segments[0].xcor() >= 290 or self.segments[0].xcor() <= -290 or self.segments[0].ycor() >= 290 or self.segments[0].ycor() <= -290:
            return -1
        return 0



