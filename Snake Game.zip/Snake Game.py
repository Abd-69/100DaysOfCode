from turtle import Screen
import time
from Snake import Snake, game_over
from Food import Food
from ScoreBoard import Scoreboard

screen = Screen()
screen.tracer(0)
screen.setup(600,600)
screen.bgcolor("black")
screen.title("--Snake Game--")
screen.listen()

snake = Snake()
food = Food()
scoreboard = Scoreboard()


screen.onkey(snake.up, "Up")
screen.onkey(snake.down, "Down")
screen.onkey(snake.left, "Left")
screen.onkey(snake.right, "Right")

game_is_on = True
while game_is_on:
    screen.update()
    time.sleep(0.1)
    snake.move()
    if snake.segments[0].distance(food) <= 15:
        food.render()
        snake.extend()
        scoreboard.increase_score()
    if snake.detect_collision() == -1:
        game_over.write("Game Over", font=("Arial", 10, "bold"), align= "center")
        game_is_on = False

    for segment in snake.segments:
        if segment == snake.segments[0]:
            pass
        elif snake.segments[0].distance(segment) < 10:
            game_is_on = False
            game_over.write("Game Over", font=("Arial", 10, "bold"), align="center")









screen.exitonclick()