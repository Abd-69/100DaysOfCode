##################### Extra Hard Starting Project ######################

from datetime import *
import pandas
from smtplib import *
import random

Gmail = "abdullahkaleem0163@gmail.com"
Password ="ltwblljwjwlaabgk"


today_day = datetime.today().day
today_month = datetime.today().month
birthdays = pandas.read_csv("birthdays.csv")
for (index, row) in birthdays.iterrows():
    if row["month"] == today_month and row["day"] == today_day:
        letters = ["letter_templates/letter_1.txt", "letter_templates/letter_2.txt", "letter_templates/letter_2.txt"]
        with open(random.choice(letters), "r") as letter_file:
            letter = letter_file.read()

        connection = SMTP("smtp.gmail.com")
        personalized_letter = letter.replace("[NAME]", row["name"]).replace("Angela", "Abd")
        connection.starttls()
        connection.login(user=Gmail, password= Password)
        connection.sendmail(from_addr= Gmail, to_addrs= row["email"], msg= f"Subject: Happy Birthday\n\n {personalized_letter}")
        connection.close()





