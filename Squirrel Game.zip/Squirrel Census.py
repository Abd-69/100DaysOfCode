import pandas

data = pandas.read_csv("2018_Central_Park_Squirrel_Census_-_Squirrel_Data.csv")

GraySquirrels_count = len(data[data["Primary Fur Color"] == "Gray"])
CinnamonSquirrels_count = len(data[data["Primary Fur Color"] == "Cinnamon"])
BlackSquirrels_count = len(data[data["Primary Fur Color"] == "Black"])

data_dictionary = {
    "Fur Color" : ["Gray", "Cinnamon", "Black"],
    "Count" : [GraySquirrels_count, CinnamonSquirrels_count, BlackSquirrels_count]
}

pandas.DataFrame(data_dictionary).to_csv("squirrel_count.csv")
