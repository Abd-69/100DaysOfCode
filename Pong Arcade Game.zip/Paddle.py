from turtle import Turtle

class Paddle(Turtle):

    def __init__(self, position):
        super().__init__("square")
        self.penup()
        self.color("white")
        self.shapesize(5, 1)
        self.goto(position[0], position[1])

    def up(self):
        y = self.ycor()
        self.sety(y + 20)

    def down(self):
        y = self.ycor()
        self.sety(y - 20)