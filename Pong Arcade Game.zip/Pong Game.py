from turtle import Screen
from Paddle import Paddle
from Ball import Ball
import time
from Scoreboard import ScoreBoard


screen = Screen()
screen.bgcolor("black")
screen.setup(800,600)
screen.title("Pong Arcade Game")
screen.listen()
screen.tracer(0)

r_paddle = Paddle((350,0))
l_paddle = Paddle((-350,0))
ball = Ball()
scoreboard = ScoreBoard()

screen.onkey(r_paddle.up, "Up")
screen.onkey(r_paddle.down, "Down")

screen.onkey(l_paddle.up, "w")
screen.onkey(l_paddle.down, "s")

game_is_on = True

while game_is_on:
    time.sleep(0.08)
    screen.update()
    ball.move()
    if ball.ycor() >= 290 or ball.ycor() <= -290:
        ball.bounce()
    if ball.distance(r_paddle) < 50 and ball.xcor() > 320:
        ball.bounce_x()
        ball.increase_speed()
    if ball.distance(l_paddle) < 50 and ball.xcor() < -320:
        ball.bounce_x()
        ball.increase_speed()

    if ball.xcor() >= 390:
        scoreboard.increase_l_score()
        ball.reset_position()

    elif ball.xcor() <= -390:
        scoreboard.increase_r_score()
        ball.reset_position()


screen.exitonclick()