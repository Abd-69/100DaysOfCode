from turtle import Turtle

class Ball(Turtle):
    def __init__(self):
        super().__init__("circle")
        self.move_x = 10
        self.move_y = 10
        self.penup()
        self.color("white")

    def move(self):
        x_cor = self.xcor()
        y_cor = self.ycor()
        self.setx(x_cor + self.move_x)
        self.sety(y_cor + self.move_y)

    def bounce(self):
        self.move_y *= -1

    def bounce_x(self):
        self.move_x *= -1

    def reset_position(self):
        self.goto(0, 0)
        self.move_x = 10 * (1 if self.move_x > 0 else -1)
        self.move_y = 10 * (1 if self.move_y > 0 else -1)
        self.bounce_x()

    def increase_speed(self):
        self.move_x *= 1.1
        self.move_y *= 1.1




