from turtle import Turtle

class ScoreBoard(Turtle):
    def __init__(self):
        super().__init__()
        self.color("white")
        self.hideturtle()
        self.penup()
        self.goto(0,280)
        self.r_score = 0
        self.l_score = 0
        self.write(f"{self.l_score} -Scores- {self.r_score}", align= "center")
        self.update_score()

    def update_score(self):
        self.clear()
        self.write(f"{self.l_score} -Scores- {self.r_score}", align= "center")

    def increase_r_score(self):
        self.r_score += 1
        self.update_score()

    def increase_l_score(self):
        self.l_score += 1
        self.update_score()

    def game_over(self, winner):
        self.goto(0,0)
        self.write(f"GAME OVER {winner} won!")


